# IP Review

Potential protectable areas include original scenario content, rule configurations, report outputs, UX and possibly specific methods for sequence-conditioned dynamic competency graphs. Formal legal review is required.
