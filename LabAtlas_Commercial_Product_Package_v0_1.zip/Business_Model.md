# Business Model

Beachhead: cell-culture and contamination-response training.

Revenue: paid pilots, departmental licence, enterprise licence, custom scenarios.
