Continue LabAtlas as a browser-first commercial MVP. Start by producing the scenario JSON, competency atlas JSON and a simple working prototype with deterministic replay and supervisor report.
