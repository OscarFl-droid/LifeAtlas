# UX Wireframes

Trainee: lab workspace, object actions, notebook, communication channel, status.

Supervisor: readiness summary, atlas, timeline, evidence details, replay controls, export.
