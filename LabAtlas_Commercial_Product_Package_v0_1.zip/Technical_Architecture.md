# Technical Architecture

Modules:
- Scenario Runtime
- Event Log
- Rule Engine
- State Engine
- Competency Atlas
- Report Generator
- Replay Engine
- Persistence Layer

The scenario is content-driven through JSON and should not require engine edits for each procedure.
