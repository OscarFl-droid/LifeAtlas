# Pilot Study Protocol

Compare experienced and novice laboratory personnel using LabAtlas and a conventional quiz. Primary hypothesis: the competency atlas aligns better with expert judgement than final-score assessment alone.
