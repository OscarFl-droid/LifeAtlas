# LabAtlas Product Package

Open `LabAtlas_PRD_v0.1.docx` first, then the pitch deck and JSON specifications.
